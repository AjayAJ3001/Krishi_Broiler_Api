require('dotenv').config();
const puppeteer = require('puppeteer');
const path = require('path');
const fs = require('fs');
const qs = require("qs");
const ejs = require('ejs');
const { format } = require('date-fns');
const { query } = require("../config/db");
const { fetchEWayBillNumber } = require("../services/ewayBillGeneration");
const { getStateCodeByName } = require("../services/getStateCode");
const { convertToSAP } = require('../services/sapConvert');
const { default: axios } = require('axios');

// ---------------- SAP CONFIG -----------------
const SAP_BASE_URL = process.env.SAP_BASE_URL;
const SAP_USERNAME = process.env.SAP_USERNAME;
const SAP_PASSWORD = process.env.SAP_PASSWORD;

function formatDateString(dateStr) {
    if (!dateStr) return null;
    const [datePart, timePart, meridian] = dateStr.split(" ");
    const [day, month, year] = datePart.split("/").map(Number);
    let [hour, minute, second] = timePart.split(":").map(Number);

    if (meridian?.toLowerCase() === "pm" && hour < 12) hour += 12;
    if (meridian?.toLowerCase() === "am" && hour === 12) hour = 0;
    return `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")} ${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}:${String(second).padStart(2, "0")}`;
}


exports.getAll = async (req, res) => {
    console.log("=============> : ", req.params)
    try {
        const { location_id } = req.params;

        let result;

        if (!location_id || location_id === 'null') {
            result = await query(`
                SELECT 
                    dc.*, 
                    sa.sap_code, 
                    sa.sap_name, 
                    sa.address
                FROM 
                    delivery_challan dc
                LEFT JOIN 
                    Shipping_Address sa 
                ON 
                    dc.ship_to__id = sa.id
                ORDER BY 
                    dc.created_at DESC
            `);
        } else {
            result = await query(`
                SELECT 
                    dc.*, 
                    sa.sap_code, 
                    sa.sap_name, 
                    sa.address
                FROM 
                    delivery_challan dc
                LEFT JOIN 
                    Shipping_Address sa 
                ON 
                    dc.ship_to__id = sa.id
                WHERE 
                    dc.dispatch_from_id = $1
                ORDER BY 
                    dc.created_at DESC
            `, [location_id]);
        }

        if (result.length === 0) {
            return res.status(404).json({
                status: false,
                message: 'No delivery challans found'
            });
        }

        res.status(200).json({ status: true, data: result });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            status: false,
            message: 'Error while fetching delivery challans',
            error: error.message
        });
    }
};

// exports.getAllById = async (req, res) => {
//     try {
//         const { user_id } = req.params;

//         let queryText = `
//             SELECT 
//                 dc.*, 
//                 sa.sap_code, 
//                 sa.sap_name, 
//                 sa.address
//             FROM 
//                 delivery_challan dc
//             LEFT JOIN 
//                 Shipping_Address sa 
//             ON 
//                 dc.ship_to__id = sa.id
//         `;
//         const queryParams = [];

//         if (user_id) {
//             queryText += ` WHERE dc.user_id = $1`;
//             queryParams.push(user_id);
//         }

//         queryText += ` ORDER BY dc.created_at DESC`;

//         const result = await query(queryText, queryParams);

//         if (result.length === 0) {
//             return res.status(404).json({ status: false, message: 'No delivery challans found' });
//         }

//         res.status(200).json({ status: true, data: result });
//     } catch (error) {
//         console.error(error);
//         res.status(500).json({ status: false, message: 'Error while fetching delivery challans', error: error.message });
//     }
// };


exports.getAllById = async (req, res) => {
    try {
        const { user_id } = req.params;

        // If no user_id → return all DC
        if (!user_id) {
            const result = await query(`
                SELECT dc.*, sa.sap_code, sa.sap_name, sa.address
                FROM delivery_challan dc
                LEFT JOIN Shipping_Address sa ON dc.ship_to__id = sa.id
                ORDER BY dc.created_at DESC
            `);

            if (!result.length) {
                return res.status(404).json({ status: false, message: 'No delivery challans found' });
            }

            return res.json({ status: true, data: result });
        }

        // Check the role of the user
        const userRow = await query(
            `SELECT role FROM driver WHERE id = $1`,
            [user_id]
        );

        if (!userRow.length) {
            return res.status(404).json({ status: false, message: "User not found" });
        }

        const role = userRow[0].role;

        let queryText;
        let params = [];

        if (role === "admin") {
            // Admin → get all DC
            queryText = `
                SELECT dc.*, sa.sap_code, sa.sap_name, sa.address
                FROM delivery_challan dc
                LEFT JOIN Shipping_Address sa ON dc.ship_to__id = sa.id
                ORDER BY dc.created_at DESC
            `;
        } else {
            // User → only their own DC
            queryText = `
                SELECT dc.*, sa.sap_code, sa.sap_name, sa.address
                FROM delivery_challan dc
                LEFT JOIN Shipping_Address sa ON dc.ship_to__id = sa.id
                WHERE dc.user_id = $1
                ORDER BY dc.created_at DESC
            `;
            params = [user_id];
        }

        const result = await query(queryText, params);

        if (!result.length) {
            return res.status(404).json({ status: false, message: 'No delivery challans found' });
        }

        return res.json({ status: true, data: result });

    } catch (error) {
        console.error(error);
        return res.status(500).json({
            status: false,
            message: "Error while fetching delivery challans",
            error: error.message
        });
    }
};



async function getDCReportById(dcId) {
    const reportQuery = `
        SELECT
            dc.id as s_no,
            dc.created_at AS doc_date,
            dc.doc_no,
            dc.token_no,
            dc.status,
            dc.reason,
            po_material.supplier__id AS supplier_id,
            s.name AS supplier_name,
            sl.address ->> 'full_address' AS "address",
            sa.address ->> 'full_address' AS "to",
            dc.truck_no,
            dc.rr_no,
            ewb.ewbno AS e_way_bill_no,
            ewb.distance,
            po_material.po_no as "po_number",
            po_material.bill_no as bill_number,
            
            material_details.name AS materials,
            (material_details.quantity)::numeric AS quantity,
            material_details.mat_id,
            material_details.unit_name,
           material_details."noOfBags" AS no_of_bags,
            mat.hsn_code,
            mat.id AS material_number,
            mat.material_code,
            (po_material.price)::numeric AS base_price,
            (mat.cgst)::numeric AS cgst_rate,
            (mat.sgst)::numeric AS sgst_rate
        FROM public.delivery_challan dc
        CROSS JOIN LATERAL jsonb_to_recordset(dc.materials::jsonb)
            AS material_details(id int, mat_id text, name text, quantity text, "noOfBags" text, unit_name text)
        LEFT JOIN shipping_address sa ON dc.ship_to__id = sa.id
        LEFT JOIN source_location sl ON dc.dispatch_from_id = sl.id
        LEFT JOIN ewaybill ewb ON dc.token_no  = ewb.doc_id
        LEFT JOIN material mat ON (material_details.mat_id)::integer = mat.id
        LEFT JOIN (
            SELECT p.rr_no,
                    p.po_no, 
                    p.bill_no,
                    p.supplier__id,
                   (po_mat ->> 'mat_id') AS mat_id,
                   (po_mat ->> 'price') AS price
            FROM po p, jsonb_array_elements(p.materials) AS po_mat
        ) AS po_material
            ON dc.rr_no = po_material.rr_no 
           AND material_details.mat_id = po_material.mat_id
        LEFT JOIN supplier s
            ON po_material.supplier__id = s.id;
        WHERE dc.id = $1
        ORDER BY dc.id ASC;
    `;

    const rows = await query(reportQuery, [dcId]);
    return rows;
}

// exports.getTokenNo = async (req, res) => {
//     try {
//         const { rr_no } = req.query;

//         if (!rr_no) {
//             return res.status(400).json({
//                 status: false,
//                 message: "rr_no is required"
//             });
//         }

//         // 1. Fetch PO based on rr_no
//         const poResult = await query(
//             `SELECT materials FROM po WHERE rr_no = $1 LIMIT 1`,
//             [rr_no]
//         );

//         if (poResult.length === 0) {
//             return res.status(404).json({
//                 status: false,
//                 message: "PO not found for given RR No"
//             });
//         }

//         const poMaterials = poResult[0].materials;

//         if (!Array.isArray(poMaterials) || poMaterials.length === 0) {
//             return res.status(400).json({
//                 status: false,
//                 message: "PO has no materials"
//             });
//         }

//         const firstMaterial = poMaterials[0];
//         const matId = firstMaterial.mat_id;

//         if (!matId) {
//             return res.status(400).json({
//                 status: false,
//                 message: "Material ID missing in PO"
//             });
//         }

//         // 2. Get material taxable status
//         const matResult = await query(
//             `SELECT is_taxable FROM material WHERE id = $1`,
//             [matId]
//         );

//         if (matResult.length === 0) {
//             return res.status(404).json({
//                 status: false,
//                 message: "Material not found"
//             });
//         }

//         const isTaxable = matResult[0].is_taxable === true;

//         // 3. Determine sequence type
//         const type = isTaxable ? "taxable" : "non_taxable";

//         // 4. Get sequence number (NO increment)
//         const seqResult = await query(
//             `SELECT next_number FROM doc_count WHERE type = $1`,
//             [type]
//         );

//         if (seqResult.length === 0) {
//             return res.status(500).json({
//                 status: false,
//                 message: `doc_count missing type: ${type}`
//             });
//         }

//         const seq = seqResult[0].next_number.toString().padStart(5, "0");

//         // 5. Return the number
//         return res.status(200).json({
//             status: true,
//             rr_no,
//             token_no: seq
//         });


//     } catch (error) {
//         console.error("getNextDocNumberByRR Error:", error);

//         return res.status(500).json({
//             status: false,
//             message: "Internal server error",
//             error: error.message
//         });
//     }
// };


// const getNextDocNumber = async (mat_id) => {
//     if (!mat_id) throw new Error("mat_id is required");

//     const matResult = await query(
//         `SELECT is_taxable FROM material WHERE id = $1`,
//         [mat_id]
//     );

//     if (matResult.length === 0) {
//         throw new Error("Material not found in material table");
//     }

//     const isTaxable = matResult[0].is_taxable === true;

//     // 2. Determine type
//     const type = isTaxable ? "taxable" : "non_taxable";

//     // 3. Read next number from doc_count (DO NOT increment)
//     const result = await query(
//         `SELECT next_number FROM doc_count WHERE type = $1`,
//         [type]
//     );

//     if (result.length === 0) {
//         throw new Error(`doc_count missing type: ${type}`);
//     }

//     const seq = result[0].next_number.toString().padStart(5, "0");

//     return `DC/ERD-GS/${seq}`;
// };


exports.getTokenNo = async (req, res) => {
    try {
        const { rr_no } = req.query;

        if (!rr_no) {
            return res.status(400).json({
                status: false,
                message: "rr_no is required"
            });
        }

        // 1. Fetch PO based on rr_no
        const poResult = await query(
            `SELECT materials FROM po WHERE rr_no = $1 LIMIT 1`,
            [rr_no]
        );

        if (poResult.length === 0) {
            return res.status(404).json({
                status: false,
                message: "PO not found for given RR No"
            });
        }

        const poMaterials = poResult[0].materials;

        if (!Array.isArray(poMaterials) || poMaterials.length === 0) {
            return res.status(400).json({
                status: false,
                message: "PO has no materials"
            });
        }

        const firstMaterial = poMaterials[0];
        const matId = firstMaterial.mat_id;

        if (!matId) {
            return res.status(400).json({
                status: false,
                message: "Material ID missing in PO"
            });
        }

        // 2. Get material taxable status
        const matResult = await query(
            `SELECT is_taxable FROM material WHERE id = $1`,
            [matId]
        );

        if (matResult.length === 0) {
            return res.status(404).json({
                status: false,
                message: "Material not found"
            });
        }

        const isTaxable = matResult[0].is_taxable === true;

        // 3. Determine sequence type
        const type = isTaxable ? "taxable" : "non_taxable";

        // 4. Get sequence number (NO increment)
        const seqResult = await query(
            `SELECT next_number FROM doc_count WHERE type = $1`,
            [type]
        );

        if (seqResult.length === 0) {
            return res.status(500).json({
                status: false,
                message: `doc_count missing type: ${type}`
            });
        }

        const seq = seqResult[0].next_number.toString().padStart(5, "0");

        // 5. Return the number
        return res.status(200).json({
            status: true,
            rr_no,
            token_no: seq
        });


    } catch (error) {
        console.error("getNextDocNumberByRR Error:", error);

        return res.status(500).json({
            status: false,
            message: "Internal server error",
            error: error.message
        });
    }
};


const getNextDocNumber = async (mat_id, city) => {
    if (!mat_id) throw new Error("mat_id is required");
    if (typeof city !== "string" || city.trim() === "") {
        throw new Error("city is required");
    }

    const matResult = await query(
        `SELECT is_taxable FROM material WHERE id = $1`,
        [mat_id]
    );

    if (matResult.length === 0) {
        throw new Error("Material not found in material table");
    }

    // const isTaxable = matResult[0].is_taxable === true;
    const isTaxable = Boolean(matResult[0].is_taxable);

    // 2. Determine type
    const type = isTaxable ? "taxable" : "non_taxable";
    // 2.1 Determine Location Text
    const loc_str = city.trim().charAt(0).toUpperCase();

    console.log(type)
    console.log(loc_str)

    // 3. Read next number from doc_count (DO NOT increment)
    const result = await query(
        `SELECT next_number FROM doc_count WHERE type = $1`,
        [type]
    );

    if (result.length === 0) {
        throw new Error(`doc_count missing type: ${type}`);
    }

    const seq = result[0].next_number.toString().padStart(5, "0");
    //return `DC/ERD-GS/${seq}`;
    
    const doc_str = isTaxable ? `DC/${loc_str}GT/${seq}` : `DC/${loc_str}GE/${seq}`;
    console.log(doc_str)

    return doc_str;
};


exports.addDC = async (req, res) => {

    const { rr_no, token_no, ship_to__id, dispatchFromId, truck_no, materials, pdfLink, doc_no, user_id, invoicePayload } = req.body;

    if (!rr_no || !token_no || !ship_to__id || !dispatchFromId || !truck_no || !materials) {
        return res.status(400).json({ status: false, message: 'Missing required fields' });
    }

    // console.log("Invoice Payload: ", invoicePayload);
    // return;

    try {

        // 1. Determine Taxable Status
        const mat_id = materials[0]?.mat_id;
        const matResult = await query(`SELECT is_taxable FROM material WHERE id = $1`, [mat_id]);
        if (matResult.length === 0) throw new Error("Material not found");
        const isTaxable = matResult[0].is_taxable;
        const type = isTaxable ? "taxable" : "non_taxable";

        // 2. ATOMIC UPDATE: Increment and Get the real sequence
        const seqUpdate = await query(
            `UPDATE doc_count SET next_number = next_number + 1 WHERE type = $1 RETURNING next_number`,
            [type]
        );
        const seqInt = seqUpdate[0].next_number;
        const seqStr = seqInt.toString().padStart(5, "0");

        // 3. Reconstruct Location Strings
        const fromAddressResult = await query('SELECT address FROM source_location WHERE id = $1', [dispatchFromId]);
        const loc_str = fromAddressResult[0]?.address?.city.trim().charAt(0).toUpperCase() || "X";

        // 4. GENERATE FINAL SYNCHRONIZED NUMBERS
        const final_doc_no = isTaxable ? `DC/${loc_str}GT/${seqStr}` : `DC/${loc_str}GE/${seqStr}`;

        // Correct the token_no: Keep the mobile prefix (e.g., BEN/882TCS/) but swap the digits with the real seq
        const tokenPrefix = token_no.substring(0, token_no.lastIndexOf('/') + 1);
        const final_token_no = `${tokenPrefix}${seqStr}`;

        // 5. E-WAY BILL logic (using synchronized numbers)
        const updatedPayload = {
            ...invoicePayload,
            docNo: final_doc_no,
            transDocNo: final_doc_no
        };
        const { ewbNo, ewbDate, ewbValidTill, irn, distance, error } = await fetchEWayBillNumber(updatedPayload);
        if (error) {
            return res.status(500).json({ status: false, message: "Eway Bill Error: " + error });
        }

        const formattedEwbDate = formatDateString(ewbDate);
        const formattedEwbValidTill = formatDateString(ewbValidTill);

        const ewayInsertQry = `
            INSERT INTO public.ewaybill (doc_id, ewbno, ewb_date, ewb_valid_till, irn, distance)
            VALUES ($1, $2, $3, $4, $5, $6)
            RETURNING *;
        `;

        await query(ewayInsertQry, [
            final_token_no,
            ewbNo,
            formattedEwbDate,
            formattedEwbValidTill,
            irn,
            distance,
        ]);


        // 1. Check invalid materials (0 qty or 0 bags)
        const invalidMaterial = materials.some(
            (m) => Number(m.quantity) === 0 || Number(m.noOfBags) === 0
        );

        if (invalidMaterial) {
            const insertQuery = `
                INSERT INTO delivery_challan 
                (rr_no, token_no, ship_to__id, truck_no, materials, dispatch_from_id, user_id, status, created_at, updated_at)
                VALUES ($1, $2, $3, $4, $5, $6, $7, 3, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                RETURNING *;
            `;
            const values = [rr_no, final_token_no, ship_to__id, truck_no, JSON.stringify(materials), dispatchFromId, user_id];
            const result = await query(insertQuery, values);

            return res.status(201).json({
                status: true,
                message: "Delivery challan added with status 3 (invalid material)",
                data: result[0]
            });
        }


        // ----- 2. UPDATE PO MATERIALS -----
        const poQuery = `SELECT materials FROM PO WHERE rr_no = $1`;
        const poResult = await query(poQuery, [rr_no]);

        if (poResult.length === 0) {
            return res.status(404).json({ status: false, message: "PO not found." });
        }

        const poMaterials = poResult[0].materials;

        const updatedMaterials = poMaterials.map(material => {
            const dispatched = materials.find(d => d.mat_id.toString() === material.mat_id.toString());
            if (dispatched) {
                const newQty = material.quantity - dispatched.quantity;
                const newBags = material.noOfBags - dispatched.noOfBags;
                return {
                    ...material,
                    quantity: newQty < 0 ? 0 : newQty,
                    noOfBags: newBags < 0 ? 0 : newBags
                };
            }
            return material;
        });

        await query(`UPDATE PO SET materials = $1 WHERE rr_no = $2`, [JSON.stringify(updatedMaterials), rr_no]);

        const allZero = updatedMaterials.every(m => m.quantity === 0 && m.noOfBags === 0);
        if (allZero) {
            await query(`UPDATE PO SET status = 4 WHERE rr_no = $1`, [rr_no]);
        }


        // ----- 3. INSERT / UPDATE DC -----
        const check = await query(`SELECT * FROM delivery_challan WHERE token_no = $1`, [token_no]);

        let result;
        if (check.length > 0) {
            result = await query(
                `
                UPDATE delivery_challan
                SET doc_no=$1, rr_no=$2, ship_to__id=$3, truck_no=$4,
                    materials=$5, pdf_link=$6, dispatch_from_id=$7,
                    user_id=$8, status=1, updated_at=CURRENT_TIMESTAMP
                WHERE token_no=$9
                RETURNING *;
                `,
                [doc_no, rr_no, ship_to__id, truck_no, JSON.stringify(materials), pdfLink, dispatchFromId, user_id, final_token_no]
            );
        } else {
            result = await query(
                `
                INSERT INTO delivery_challan 
                (doc_no, rr_no, token_no, ship_to__id, truck_no, materials, pdf_link,
                 dispatch_from_id, user_id, status, created_at, updated_at)
                VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,1,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)
                RETURNING *;
                `,
                [doc_no, rr_no, final_token_no, ship_to__id, truck_no, JSON.stringify(materials), pdfLink, dispatchFromId, user_id]
            );
        }

        const dcData = result[0];



        // =====================================================================
        //                           AUTO SAP PUSH
        // =====================================================================
        try {
            const dcId = dcData.id;

            const dcRows = await getDCReportById(dcId);

            // console.log("************+++++++++++++++==========> ", dcRows)
            // return res.json(dcRows);


            if (dcRows.length > 0) {
                for (const row of dcRows) {
                    const sapPayload = convertToSAP(row);

                    console.log("SAP PAYLOAD: +++++++++++++++==========> ", sapPayload)
                    // return res.json(sapPayload);


                    const qsString = qs.stringify(
                        { "sap-client": "500", ...sapPayload },
                        { encode: true }
                    );

                    const finalUrl = `${SAP_BASE_URL}?${qsString}`;

                    // const response = await axios.post(finalUrl, null, {
                    //     auth: { username: SAP_USERNAME, password: SAP_PASSWORD },
                    //     headers: { Accept: "application/json" }
                    // });

                    // url: 'http://krishiprd.krishinutrition.com:8003/sap/bc/zwagon?sap-client=500&id=341&BLDAT=2025-11-26&XBLNR=DC%2FERD-GS%2F0005&ZTO=D.No.85%2F149%2C%20Krishi%20Nutrition%20Company%20Private%20Limited%2C%20New%20Turmeric%20Marketing%20Committee%20Campus%2C%20Vettuvapalayam%20Main%20Street%2C%2C%20Nasiyanur%2C%20Erode%2C%20Tamil%20Nadu%2C%20638107%2C%2033AAFCK3415K1ZO&ZADDRESS=Krishi%20Nutrition%20Company%20Private%20Limited%2C%20C%2Fo%20Railway%20Goodshed%2C%20Namakkal%2C%20Namakkal%2C%20Tamil%20Nadu%2C%20637001%2C%2033AAFCK3415K1ZO&ZTRUCK_NO=TN10AB1020&MAKTX=MAIZE&MATNR=FR000017&ZHSN_CODE=10059000&MENGED=1.000&ZRATE=25000.00&ZCGST_PER=0.00&ZSGST_PER=0.00&ZTAXABLE_VAL=25000.00&ZCGST_AMT=0.00&ZSGST_AMT=0.00&ZGROSS_AMT=25000.00&ZEWAY=-&ZSD_DISTANCE=0&ZSTATUS=Active&ZREASON=-&ZPO_NO=Test&ZNO_OF_BAGS=1&ZRR_NO=232323232%2FJHS&ZTOKEN=NMKL%2F232JHS%2F0005&VBELN=12121212',

                    let config = {
                        method: 'post',
                        maxBodyLength: Infinity,
                        url: finalUrl,
                        headers: {
                            'Authorization': 'Basic RERJQzpLcmlzaGlQckRAMTIzNDUjQA==',
                            'Cookie': 'SAP_SESSIONID_KSP_500=-aRrLzyc7__nirnv6RaTQxae5u3KxBHwtU5PNnqbrPI%3d; sap-usercontext=sap-client=500'
                        }
                    };

                    const response = await axios.request(config)

                    // axios.request(config)
                    // .then((response) => {
                    //     console.log(JSON.stringify(response.data));
                    // })
                    // .catch((error) => {
                    //     console.log(error);
                    // });


                    console.log("------------SAP RESPONSE------------:", response.data);
                }

                await query(`UPDATE delivery_challan SET is_send_sap=true WHERE id=$1`, [dcId]);
            } else {
                console.log("No DC rows found for SAP upload.");
            }

        } catch (sapErr) {
            console.error("SAP Auto-Send Failed:", sapErr.response?.data || sapErr.message);
        }


        // =====================================================================
        //                           FINAL RESPONSE
        // =====================================================================
        return res.status(201).json({
            status: true,
            message: check.length > 0 ? "Delivery challan updated" : "Delivery challan created",
            data: dcData
        });

    } catch (error) {
        console.error(error);
        return res.status(500).json({
            status: false,
            message: "Error while adding delivery challan",
            error: error.message
        });
    }
};


exports.generateChallanPDFByData = async (req, res) => {
    try {
        const { dcData } = req.body;

        // console.log(dcData);
        // return;

        const addressQuery = 'SELECT address FROM shipping_address WHERE id = $1';
        const addressResult = await query(addressQuery, [dcData.ship_to__id]);
        const full_address = addressResult.length > 0 ? addressResult[0].address : 'N/A';

        // get From Location
        const fromAddressQuery = 'SELECT address FROM source_location WHERE id = $1';
        const fromAddressResult = await query(fromAddressQuery, [dcData.dispatchFromId]);
        const full_from_address = fromAddressResult.length > 0 ? fromAddressResult[0].address : 'N/A';

        // Generate the New Doc Number
        const doc_no = await getNextDocNumber(dcData.materials[0].mat_id, full_from_address?.city);

        // console.log(doc_no);
        // return;

        // Fetch PO details including materials JSONB
        const poQuery = 'SELECT po_no, bill_no, materials FROM PO WHERE rr_no = $1';
        const poResult = await query(poQuery, [dcData.rr_no]);
        if (poResult.length === 0) {
            return res.status(404).json({ status: false, message: 'PO not found.' });
        }

        const poDetails = poResult[0];
        const poMaterials = poDetails.materials || [];

        // Collect all material ids from PO materials
        const materialIds = poMaterials.map(m => m.mat_id);
        const materialsQuery = 'SELECT id, name, hsn_code, cgst, sgst, e_way_bill FROM Material WHERE id = ANY($1)';
        const materialsResult = await query(materialsQuery, [materialIds]);

        let isEwayBill = true;
        let total_price = 0;

        const finalMaterials = await Promise.all(dcData.materials.map(async (dispatchedMaterial) => {
            const { mat_id, quantity, noOfBags, unit_name } = dispatchedMaterial;

            // console.log(dispatchedMaterial)

            const poMaterial = poMaterials.find(m => m.mat_id.toString() === mat_id.toString());
            const materialInfo = materialsResult.find(m => m.id.toString() === mat_id.toString());

            if (!poMaterial || !materialInfo) return null;

            const orgPrice = poMaterial.price;
            const { hsn_code, cgst, sgst, e_way_bill } = materialInfo;

            // console.log("jjjjjjjjjjj----------> :", materialInfo)

            if (e_way_bill == false) {
                isEwayBill = false;
            };

            // const noOfBags = (quantity * 1000) / 55;

            const basic = orgPrice * quantity;
            const cgstAmount = basic * (cgst / 100);
            const sgstAmount = basic * (sgst / 100);

            const totalTaxPercent = (cgst + sgst) / 100;

            const price = (orgPrice + (orgPrice * totalTaxPercent))

            const total = (basic + cgstAmount + sgstAmount);

            total_price = total.toFixed(2);

            return {
                ...dispatchedMaterial,
                name: materialInfo.name,
                hsn_code,
                cgst,
                sgst,
                e_way_bill,
                price,
                unit_name: unit_name.toLowerCase() == "mt" ? "MTS" : unit_name.toUpperCase(),
                noOfBags: parseInt(noOfBags, 10),
                basic: basic.toFixed(2),
                cgstAmount: cgstAmount.toFixed(2),
                sgstAmount: sgstAmount.toFixed(2),
                total: total.toFixed(2),
            };
        }));

        const currentDate = new Date();

        let e_way_data = {}
        let invoicePayload = {}

        // console.log("is eway bill: ------------> ", isEwayBill)

        if (isEwayBill) {

            invoicePayload = {
                "supplyType": "I", "subSupplyType": "5", "subSupplyDesc": "For Own Use", "docType": "CHL",
                "docNo": doc_no,
                "docDate": format(new Date(), 'dd/MM/yyyy'),
                "fromGstin": full_from_address.gst_in,
                "fromTrdName": full_from_address.company,
                "fromAddr1": `${full_from_address.company}, ${full_from_address.street}`,
                "fromAddr2": `${full_from_address.city}, ${full_from_address.state}, ${full_from_address.pincode}`,
                "fromPlace": full_from_address.state,
                "fromPincode": parseInt(full_from_address.pincode),
                "actFromStateCode": getStateCodeByName(full_from_address.state),
                "fromStateCode": getStateCodeByName(full_from_address.state),
                "toGstin": full_address.gst_in,
                "toTrdName": full_from_address.company,
                "toAddr1": `${full_address.company}, ${full_address.door_no}`,
                "toAddr2": `${full_address.street}, ${full_address.city}, ${full_address.state}, ${full_address.pincode}`,
                "toPlace": full_address.city,
                "toPincode": parseInt(full_address.pincode),
                "actToStateCode": getStateCodeByName(full_address.state),
                "toStateCode": getStateCodeByName(full_address.state),
                "transactionType": 1,
                "otherValue": 0,
                "totalValue": parseFloat(finalMaterials[0].basic),
                "cgstValue": parseFloat(finalMaterials[0].cgstAmount),
                "sgstValue": parseFloat(finalMaterials[0].sgstAmount),
                "igstValue": 0,
                "cessValue": 0,
                "cessNonAdvolValue": 0,
                "totInvValue": parseFloat(total_price),
                "transporterId": "",
                "transporterName": "",
                "transDocNo": `${doc_no}`,
                "transMode": "1",
                "transDistance": parseInt(dcData.distance) || 0,
                "transDocDate": format(new Date(), 'dd/MM/yyyy'),
                "vehicleNo": dcData.truck_no,
                "vehicleType": "R",

                ItemList: finalMaterials.map(item => ({

                    productName: item.name,
                    productDesc: item.name,
                    hsnCode: item.hsn_code,
                    quantity: parseFloat(item.quantity),
                    qtyUnit: item.unit_name,
                    taxableAmount: parseFloat(item.basic),
                    sgstRate: parseFloat(item.sgst),
                    cgstRate: parseFloat(item.cgst),
                    igstRate: 0,
                    cessRate: 0,
                    cessNonAdvol: 0
                }))
            }

            // console.log("Final Materials: ", finalMaterials);
            // console.log("invoice Payload : ", invoicePayload);

            // return res.json({ invoicePayload });

            // const { ewbNo, ewbDate, ewbValidTill, irn, distance, error } = await fetchEWayBillNumber(invoicePayload);

            // // console.log(ewbNo, ewbDate, ewbValidTill, irn, distance)

            // if (error) {
            //     console.error("Error:", error);
            //     return res.status(500).json({ status: false, message: error });
            // }

            // function formatDateString(dateStr) {
            //     if (!dateStr) return null;

            //     // Handle formats like "13/11/2025 11:59:00 PM"
            //     const [datePart, timePart, meridian] = dateStr.split(" ");
            //     const [day, month, year] = datePart.split("/").map(Number);
            //     let [hour, minute, second] = timePart.split(":").map(Number);

            //     if (meridian?.toLowerCase() === "pm" && hour < 12) hour += 12;
            //     if (meridian?.toLowerCase() === "am" && hour === 12) hour = 0;

            //     // Return in ISO format for Postgres
            //     return `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")} ${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}:${String(second).padStart(2, "0")}`;
            // }

            // const formattedEwbDate = formatDateString(ewbDate);
            // const formattedEwbValidTill = formatDateString(ewbValidTill);

            // const ewayInsertQry = `
            //     INSERT INTO public.ewaybill (doc_id, ewbno, ewb_date, ewb_valid_till, irn, distance)
            //     VALUES ($1, $2, $3, $4, $5, $6)
            //     RETURNING *;
            // `;

            // const result = await query(ewayInsertQry, [
            //     dcData.token_no,
            //     ewbNo,
            //     formattedEwbDate,
            //     formattedEwbValidTill,
            //     irn,
            //     distance,
            // ]);

            // if (result && result.length > 0) {
            //     console.log('Eway bill Data inserted successfully');
            //     console.log('Inserted Row:', result[0]);
            // } else {
            //     console.log('Failed to insert Eway bill data');
            // }

            // e_way_data = {
            //     e_way_bill_no: ewbNo?.toString(),
            //     type: 'Inward - For Own Use',
            //     date: ewbDate,
            //     valid: ewbValidTill,
            //     transaction_type: 'regular'
            // };

        }

        const templateData = {
            rr_no: dcData.rr_no,
            token_no: dcData.token_no,
            ship_to__id: dcData.ship_to__id,
            full_address,
            full_from_address,
            truck_no: dcData.truck_no,
            materials: finalMaterials.filter(m => m !== null),
            po_no: poDetails.po_no,
            bill_no: poDetails.bill_no,
            doc_no: doc_no,
            created_at: currentDate,
            updated_at: currentDate.toLocaleDateString(),
            status: dcData.status === 1 ? 'Approved' : 'Pending',
            e_way_data,
            isEwayBill,
            viewMode: true
        };

        // console.log(templateData)

        const htmlTemplatePath = path.join(process.cwd(), 'templates', 'dc-challan.ejs');
        const htmlContent = await ejs.renderFile(htmlTemplatePath, templateData);

        const reportsDir = path.join(process.cwd(), 'challans');
        if (!fs.existsSync(reportsDir)) {
            fs.mkdirSync(reportsDir);
        }

        const safeDocPart = String(doc_no || "UNKNOWN").split('/')[2] || "NA";
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');

        const fileName = `${safeDocPart}_${timestamp}.pdf`;
        const filePath = path.join(reportsDir, fileName);
        const ChallanUrl = `${process.env.SERVER_URL}/challans/${fileName}`;

        const browser = await puppeteer.launch({
            headless: 'new',
            args: ['--no-sandbox', '--disable-setuid-sandbox'],
        });
        const page = await browser.newPage();
        await page.setContent(htmlContent, { waitUntil: 'networkidle0' });

        await page.pdf({
            path: filePath,
            format: 'A4',
            printBackground: true,
            margin: { top: '40px', bottom: '40px', left: '40px', right: '40px' },
        });
        await browser.close();

        return res.status(200).json({
            status: true,
            message: 'PDF generated successfully!',
            dcData: { ...dcData, invoicePayload },
            pdfLink: ChallanUrl,
            doc_no,
            templateData
        });

    } catch (error) {
        console.error('Error generating PDF from body:', error);
        return res.status(500).json({
            status: false,
            message: 'An error occurred while generating the PDF.',
            error: error.message,
        });
    }
};


exports.updateDC = async (req, res) => {
    const { id } = req.params;
    const { status } = req.body;

    if ((status === undefined)) {
        return res.status(400).json({ status: false, message: 'Missing required fields' });
    }

    if (![0, 1, 2].includes(status)) {
        return res.status(400).json({ status: false, message: 'Invalid status. Status must be 0, 1, or 2.' });
    }

    try {
        const checkQuery = 'SELECT * FROM public.delivery_challan WHERE id = $1';
        const checkResult = await query(checkQuery, [id]);

        if (checkResult.length === 0) {
            return res.status(404).json({ status: false, message: 'Delivery challan not found' });
        }

        const queryText = `
            UPDATE public.delivery_challan
            SET status = $1, updated_at = CURRENT_TIMESTAMP
            WHERE id = $2
            RETURNING *;
        `;
        const values = [status, id];
        const result = await query(queryText, values);

        res.status(200).json({
            status: true,
            message: 'Delivery challan updated successfully',
            data: result[0],
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            status: false,
            message: 'Error while updating delivery challan',
            error: error.message,
        });
    }
};

const updateDeliveryChallan = async (updateData) => {
    const { doc_no, token_no, ship_to__id, dispatchFromId, truck_no, materials, pdfLink, } = updateData;

    if (!doc_no) {
        throw new Error('doc_no is required for updating challan.');
    }

    // Build dynamic query
    const fields = [];
    const values = [];
    let index = 1;

    if (token_no) {
        fields.push(`token_no = $${index++}`);
        values.push(token_no);
    }

    if (ship_to__id) {
        fields.push(`ship_to__id = $${index++}`);
        values.push(ship_to__id);
    }

    if (dispatchFromId) {
        fields.push(`dispatch_from_id = $${index++}`);
        values.push(dispatchFromId);
    }

    if (truck_no) {
        fields.push(`truck_no = $${index++}`);
        values.push(truck_no);
    }

    if (materials) {
        fields.push(`materials = $${index++}`);
        values.push(JSON.stringify(materials));
    }

    if (pdfLink) {
        fields.push(`pdf_link = $${index++}`);
        values.push(pdfLink);
    }

    fields.push(`updated_at = CURRENT_TIMESTAMP`);

    const updateQuery = `
        UPDATE delivery_challan
        SET ${fields.join(', ')}
        WHERE doc_no = $${index}
        RETURNING *;
    `;

    values.push(doc_no);

    const result = await query(updateQuery, values);

    if (result.length === 0) {
        throw new Error('Delivery Challan not found or no fields updated.');
    }

    return result[0];
};

exports.generateChallanPDFByData = async (req, res) => {
    try {
        const { dcData } = req.body;

        // console.log(dcData);
        // return;

        const addressQuery = 'SELECT address FROM shipping_address WHERE id = $1';
        const addressResult = await query(addressQuery, [dcData.ship_to__id]);
        const full_address = addressResult.length > 0 ? addressResult[0].address : 'N/A';

        // get From Location
        const fromAddressQuery = 'SELECT address FROM source_location WHERE id = $1';
        const fromAddressResult = await query(fromAddressQuery, [dcData.dispatchFromId]);
        const full_from_address = fromAddressResult.length > 0 ? fromAddressResult[0].address : 'N/A';

        // Generate the New Doc Number
        const doc_no = await getNextDocNumber(dcData.materials[0].mat_id, full_from_address?.city);

        // console.log(doc_no);
        // return;

        // Fetch PO details including materials JSONB
        const poQuery = 'SELECT po_no, bill_no, materials FROM PO WHERE rr_no = $1';
        const poResult = await query(poQuery, [dcData.rr_no]);
        if (poResult.length === 0) {
            return res.status(404).json({ status: false, message: 'PO not found.' });
        }

        const poDetails = poResult[0];
        const poMaterials = poDetails.materials || [];

        // Collect all material ids from PO materials
        const materialIds = poMaterials.map(m => m.mat_id);
        const materialsQuery = 'SELECT id, name, hsn_code, cgst, sgst, e_way_bill FROM Material WHERE id = ANY($1)';
        const materialsResult = await query(materialsQuery, [materialIds]);

        let isEwayBill = true;
        let total_price = 0;

        const finalMaterials = await Promise.all(dcData.materials.map(async (dispatchedMaterial) => {
            const { mat_id, quantity, noOfBags, unit_name } = dispatchedMaterial;

            // console.log(dispatchedMaterial)

            const poMaterial = poMaterials.find(m => m.mat_id.toString() === mat_id.toString());
            const materialInfo = materialsResult.find(m => m.id.toString() === mat_id.toString());

            if (!poMaterial || !materialInfo) return null;

            const orgPrice = poMaterial.price;
            const { hsn_code, cgst, sgst, e_way_bill } = materialInfo;

            // console.log("jjjjjjjjjjj----------> :", materialInfo)

            if (e_way_bill == false) {
                isEwayBill = false;
            };

            // const noOfBags = (quantity * 1000) / 55;

            const basic = orgPrice * quantity;
            const cgstAmount = basic * (cgst / 100);
            const sgstAmount = basic * (sgst / 100);

            const totalTaxPercent = (cgst + sgst) / 100;

            const price = (orgPrice + (orgPrice * totalTaxPercent))

            const total = (basic + cgstAmount + sgstAmount);

            total_price = total.toFixed(2);

            return {
                ...dispatchedMaterial,
                name: materialInfo.name,
                hsn_code,
                cgst,
                sgst,
                e_way_bill,
                price,
                unit_name: unit_name.toLowerCase() == "mt" ? "MTS" : unit_name.toUpperCase(),
                noOfBags: parseInt(noOfBags, 10),
                basic: basic.toFixed(2),
                cgstAmount: cgstAmount.toFixed(2),
                sgstAmount: sgstAmount.toFixed(2),
                total: total.toFixed(2),
            };
        }));

        const currentDate = new Date();

        let e_way_data = {}

        // console.log("is eway bill: ------------> ", isEwayBill)

        if (isEwayBill) {

            const invoicePayload = {
                "supplyType": "I", "subSupplyType": "5", "subSupplyDesc": "For Own Use", "docType": "CHL",
                "docNo": doc_no,
                "docDate": format(new Date(), 'dd/MM/yyyy'),
                "fromGstin": full_from_address.gst_in,
                "fromTrdName": full_from_address.company,
                "fromAddr1": `${full_from_address.company}, ${full_from_address.street}`,
                "fromAddr2": `${full_from_address.city}, ${full_from_address.state}, ${full_from_address.pincode}`,
                "fromPlace": full_from_address.state,
                "fromPincode": parseInt(full_from_address.pincode),
                "actFromStateCode": getStateCodeByName(full_from_address.state),
                "fromStateCode": getStateCodeByName(full_from_address.state),
                "toGstin": full_address.gst_in,
                "toTrdName": full_from_address.company,
                "toAddr1": `${full_address.company}, ${full_address.door_no}`,
                "toAddr2": `${full_address.street}, ${full_address.city}, ${full_address.state}, ${full_address.pincode}`,
                "toPlace": full_address.city,
                "toPincode": parseInt(full_address.pincode),
                "actToStateCode": getStateCodeByName(full_address.state),
                "toStateCode": getStateCodeByName(full_address.state),
                "transactionType": 1,
                "otherValue": Math.round(parseFloat(total_price)),
                "totalValue": parseFloat(finalMaterials[0].basic),
                "cgstValue": parseFloat(finalMaterials[0].cgstAmount),
                "sgstValue": parseFloat(finalMaterials[0].sgstAmount),
                "igstValue": 0,
                "cessValue": 0,
                "cessNonAdvolValue": 0,
                "totInvValue": parseFloat(total_price),
                "transporterId": "",
                "transporterName": "",
                // "transDocNo": `${doc_no}`,
                "transDocNo": "",
                "transMode": "1",
                "transDistance": parseInt(dcData.distance) || 0,
                // "transDocDate": format(new Date(), 'dd/MM/yyyy'),
                "transDocDate": "",
                "vehicleNo": dcData.truck_no,
                "vehicleType": "R",

                ItemList: finalMaterials.map(item => ({

                    productName: item.name,
                    productDesc: item.name,
                    hsnCode: item.hsn_code,
                    quantity: parseFloat(item.quantity),
                    qtyUnit: item.unit_name,
                    taxableAmount: parseFloat(item.basic),
                    sgstRate: parseFloat(item.sgst),
                    cgstRate: parseFloat(item.cgst),
                    igstRate: 0,
                    cessRate: 0,
                    cessNonAdvol: 0
                }))
            }

            console.log("Final Materials: ", finalMaterials);
            console.log("invoice Payload : ", invoicePayload);

            // return res.json({ invoicePayload });

            // const { ewbNo, ewbDate, ewbValidTill, irn, distance, error } = await fetchEWayBillNumber(invoicePayload, ewayPayload);
            const { ewbNo, ewbDate, ewbValidTill, irn, distance, error } = await fetchEWayBillNumber(invoicePayload);

            // console.log(ewbNo, ewbDate, ewbValidTill, irn, distance)

            if (error) {
                console.error("Error:", error);
                return res.status(500).json({ status: false, message: error });
            }

            function formatDateString(dateStr) {
                if (!dateStr) return null;

                // Handle formats like "13/11/2025 11:59:00 PM"
                const [datePart, timePart, meridian] = dateStr.split(" ");
                const [day, month, year] = datePart.split("/").map(Number);
                let [hour, minute, second] = timePart.split(":").map(Number);

                if (meridian?.toLowerCase() === "pm" && hour < 12) hour += 12;
                if (meridian?.toLowerCase() === "am" && hour === 12) hour = 0;

                // Return in ISO format for Postgres
                return `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")} ${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}:${String(second).padStart(2, "0")}`;
            }

            const formattedEwbDate = formatDateString(ewbDate);
            const formattedEwbValidTill = formatDateString(ewbValidTill);

            const ewayInsertQry = `
                INSERT INTO public.ewaybill (doc_id, ewbno, ewb_date, ewb_valid_till, irn, distance)
                VALUES ($1, $2, $3, $4, $5, $6)
                RETURNING *;
            `;

            const result = await query(ewayInsertQry, [
                dcData.token_no,
                ewbNo,
                formattedEwbDate,
                formattedEwbValidTill,
                irn,
                distance,
            ]);

            if (result && result.length > 0) {
                console.log('Eway bill Data inserted successfully');
                console.log('Inserted Row:', result[0]);
            } else {
                console.log('Failed to insert Eway bill data');
            }

            e_way_data = {
                e_way_bill_no: ewbNo?.toString(),
                type: 'Inward - For Own Use',
                date: ewbDate,
                valid: ewbValidTill,
                transaction_type: 'regular'
            };

        }

        const templateData = {
            rr_no: dcData.rr_no,
            token_no: dcData.token_no,
            ship_to__id: dcData.ship_to__id,
            full_address,
            full_from_address,
            truck_no: dcData.truck_no,
            // other_amt: finalMaterials.filter(m => m !== null).reduce((sum, m) => sum + Math.round(Number(m.total || 0)), 0),
            materials: finalMaterials.filter(m => m !== null),
            po_no: poDetails.po_no,
            bill_no: poDetails.bill_no,
            doc_no: doc_no,
            created_at: currentDate,
            updated_at: currentDate.toLocaleDateString(),
            status: dcData.status === 1 ? 'Approved' : 'Pending',
            e_way_data,
            isEwayBill
        };

        console.log(templateData)

        const htmlTemplatePath = path.join(process.cwd(), 'templates', 'dc-challan.ejs');
        const htmlContent = await ejs.renderFile(htmlTemplatePath, templateData);

        const reportsDir = path.join(process.cwd(), 'challans');
        if (!fs.existsSync(reportsDir)) {
            fs.mkdirSync(reportsDir);
        }

        const fileName = `${doc_no.split('/')[2]}.pdf`;
        const filePath = path.join(reportsDir, fileName);
        const ChallanUrl = `${process.env.SERVER_URL}/challans/${fileName}`;

        const browser = await puppeteer.launch({
            headless: 'new',
            args: ['--no-sandbox', '--disable-setuid-sandbox'],
        });
        const page = await browser.newPage();
        await page.setContent(htmlContent, { waitUntil: 'networkidle0' });

        await page.pdf({
            path: filePath,
            format: 'A4',
            printBackground: true,
            margin: { top: '40px', bottom: '40px', left: '40px', right: '40px' },
        });
        await browser.close();

        return res.status(200).json({
            status: true,
            message: 'PDF generated successfully!',
            dcData: dcData,
            pdfLink: ChallanUrl,
            doc_no,
            templateData
        });

    } catch (error) {
        console.error('Error generating PDF from body:', error);
        return res.status(500).json({
            status: false,
            message: 'An error occurred while generating the PDF.',
            error: error.message,
        });
    }
};


exports.generateChallanPDFByViewData = async (req, res) => {
    try {
        const { dcData } = req.body;

        // console.log("-------------------------> DC: ", dcData);
        // return;

        const addressQuery = 'SELECT address FROM shipping_address WHERE id = $1';
        const addressResult = await query(addressQuery, [dcData.ship_to__id]);
        const full_address = addressResult.length > 0 ? addressResult[0].address : 'N/A';

        // get From Location
        const fromAddressQuery = 'SELECT address FROM source_location WHERE id = $1';
        const fromAddressResult = await query(fromAddressQuery, [dcData.dispatch_from_id]);
        const full_from_address = fromAddressResult.length > 0 ? fromAddressResult[0].address : 'N/A';


        // Fetch PO details including materials JSONB
        const poQuery = 'SELECT po_no, bill_no, materials FROM PO WHERE rr_no = $1';
        const poResult = await query(poQuery, [dcData.rr_no]);
        if (poResult.length === 0) {
            return res.status(404).json({ status: false, message: 'PO not found.' });
        }

        const poDetails = poResult[0];
        const poMaterials = poDetails.materials || [];

        // Collect all material ids from PO materials
        const materialIds = poMaterials.map(m => m.mat_id);
        const materialsQuery = 'SELECT id, name, hsn_code, cgst, sgst, e_way_bill FROM Material WHERE id = ANY($1)';
        const materialsResult = await query(materialsQuery, [materialIds]);

        let isEwayBill = true;

        const finalMaterials = await Promise.all(dcData.materials.map(async (dispatchedMaterial) => {
            const { mat_id, quantity, noOfBags } = dispatchedMaterial;

            // console.log(dispatchedMaterial)

            const poMaterial = poMaterials.find(m => m.mat_id.toString() === mat_id.toString());
            const materialInfo = materialsResult.find(m => m.id.toString() === mat_id.toString());

            if (!poMaterial || !materialInfo) return null;

            const orgPrice = poMaterial.price;
            const { hsn_code, cgst, sgst, e_way_bill } = materialInfo;

            // const noOfBags = (quantity * 1000) / 55;

            if (e_way_bill == false) {
                isEwayBill = false;
            };

            const basic = orgPrice * quantity;
            const cgstAmount = basic * (cgst / 100);
            const sgstAmount = basic * (sgst / 100);

            const totalTaxPercent = (cgst + sgst) / 100;

            const price = orgPrice + (orgPrice * totalTaxPercent)
            const total = basic + cgstAmount + sgstAmount;

            // const price = Math.round(orgPrice + (orgPrice * totalTaxPercent))
            // const total = Math.ceil(basic + cgstAmount + sgstAmount);

            return {
                ...dispatchedMaterial,
                name: materialInfo.name,
                hsn_code,
                cgst,
                sgst,
                price: price.toFixed(2),
                noOfBags: parseInt(noOfBags, 10),
                basic: basic.toFixed(2),
                cgstAmount: cgstAmount.toFixed(2),
                sgstAmount: sgstAmount.toFixed(2),
                total: total.toFixed(2),
            };
        }));

        const currentDate = new Date();


        const ewayFetchQry = `
            SELECT * 
            FROM public.ewaybill 
            WHERE doc_id = $1
            ORDER BY created_at DESC
            LIMIT 1;
        `;
        const ewayRes = await query(ewayFetchQry, [dcData.token_no]);

        // console.log("=============> ", ewayRes)

        function formatDateTime(date) {
            const pad = num => num.toString().padStart(2, '0');
            return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ` +
                `${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
        }

        // ewayRes[0]?.ewb_date = formatDateTime(new Date(ewayRes[0]?.ewb_date));
        // ewayRes[0]?.ewb_valid_till = formatDateTime(new Date(ewayRes[0]?.ewb_valid_till));

        const e_way_data = {
            e_way_bill_no: ewayRes[0]?.ewbno,
            type: 'Inward - For Own Use',
            date: formatDateTime(new Date(ewayRes[0]?.ewb_date)),
            valid: formatDateTime(new Date(ewayRes[0]?.ewb_valid_till)),
            transaction_type: 'regular'
        };

        // console.log(e_way_data)


        const templateData = {
            rr_no: dcData.rr_no,
            token_no: dcData.token_no,
            ship_to__id: dcData.ship_to__id,
            full_address,
            full_from_address,
            truck_no: dcData.truck_no,
            materials: finalMaterials.filter(m => m !== null),
            po_no: poDetails.po_no,
            bill_no: poDetails.bill_no,
            doc_no: dcData.doc_no,
            // created_at: currentDate,
            // updated_at: currentDate.toLocaleDateString(),
            created_at: dcData.created_at,
            updated_at: dcData.updated_at,
            status: dcData.status === 1 ? 'Active' : 'Cancelled',
            e_way_data,
            isEwayBill,
            viewMode: false
        };

        // console.log(templateData)

        const htmlTemplatePath = path.join(process.cwd(), 'templates', 'dc-challan.ejs');
        const htmlContent = await ejs.renderFile(htmlTemplatePath, templateData);

        const reportsDir = path.join(process.cwd(), 'challans');
        if (!fs.existsSync(reportsDir)) {
            fs.mkdirSync(reportsDir);
        }

        const fileName = `${dcData.doc_no.split('/')[2]}.pdf`;
        const filePath = path.join(reportsDir, fileName);
        const ChallanUrl = `${process.env.SERVER_URL}/challans/${fileName}`;

        const browser = await puppeteer.launch({
            headless: 'new',
            args: ['--no-sandbox', '--disable-setuid-sandbox'],
        });
        const page = await browser.newPage();
        await page.setContent(htmlContent, { waitUntil: 'networkidle0' });
        await page.pdf({
            path: filePath,
            format: 'A4',
            printBackground: true,
            margin: { top: '40px', bottom: '40px', left: '40px', right: '40px' },
        });
        await browser.close();



        return res.status(200).json({
            status: true,
            message: 'PDF generated successfully!',
            dcData: dcData,
            pdfLink: ChallanUrl,
            templateData
        });

    } catch (error) {
        console.error('Error generating PDF from body:', error);
        return res.status(500).json({
            status: false,
            message: 'An error occurred while generating the PDF.',
            error: error.message,
        });
    }
};


exports.cancelDC = async (req, res) => {
    const { id } = req.params;
    const { status, reason } = req.body;

    if (status === undefined) {
        return res.status(400).json({ status: false, message: "Missing required fields" });
    }

    if (![0, 1, 2].includes(status)) {
        return res.status(400).json({ status: false, message: "Invalid status. Must be 0, 1, or 2." });
    }

    try {
        const checkResult = await query(
            `SELECT * FROM delivery_challan WHERE id = $1`,
            [id]
        );

        if (checkResult.length === 0) {
            return res.status(404).json({ status: false, message: "Delivery challan not found" });
        }

        // ------------------ UPDATE DC STATUS ------------------
        const updated = await query(
            `
            UPDATE delivery_challan
            SET status=$1, reason=$2, updated_at=CURRENT_TIMESTAMP
            WHERE id=$3
            RETURNING *;
            `,
            [status, reason, id]
        );

        const dcData = updated[0];


        // ======================================================
        //                     SEND CANCEL TO SAP
        // ======================================================
        try {
            const dcRows = await getDCReportById(id);

            if (dcRows.length > 0) {
                for (let row of dcRows) {
                    // override fields BEFORE conversion
                    row.status = dcData.status;
                    row.reason = dcData.reason;

                    let sapPayload = convertToSAP(row);

                    // SPECIAL CASE — ensure cancellation logic is explicit
                    sapPayload.ZSTATUS = "Cancelled";
                    sapPayload.ZREASON = dcData.reason || "-";

                    const qsString = qs.stringify(
                        { "sap-client": "500", ...sapPayload },
                        { encode: true }
                    );

                    const finalUrl = `${SAP_BASE_URL}?${qsString}`;

                    const response = await axios.post(finalUrl, null, {
                        auth: { username: SAP_USERNAME, password: SAP_PASSWORD },
                        headers: { Accept: "application/json" }
                    });

                    console.log("SAP CANCEL SUCCESS:", response.data);
                }

                // Update DB indicating SAP was notified
                await query(`UPDATE delivery_challan SET is_send_sap = true WHERE id = $1`, [id]);
            } else {
                console.log("No DC rows found for SAP cancel.");
            }

        } catch (sapErr) {
            console.error("SAP Cancel Send Failed:", sapErr.response?.data || sapErr.message);
        }


        // ======================================================
        //                   FINAL RESPONSE
        // ======================================================
        return res.status(200).json({
            status: true,
            message: "Delivery challan cancelled successfully",
            data: dcData
        });

    } catch (error) {
        console.error(error);
        return res.status(500).json({
            status: false,
            message: "Error while cancelling delivery challan",
            error: error.message
        });
    }
};
